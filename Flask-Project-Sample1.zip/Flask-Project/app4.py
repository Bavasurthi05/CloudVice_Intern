import sqlite3
from flask import Flask, request, render_template

app = Flask(__name__)

def init_db():
    conn = sqlite3.connect('users.db')
    conn.execute('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT)')
    conn.close()

@app.route('/')
def home():
    return render_template('db_form.html')

@app.route('/add', methods=['POST'])
def add_user():
    name = request.form['name']
    conn = sqlite3.connect('users.db')
    conn.execute('INSERT INTO users (name) VALUES (?)', (name,))
    conn.commit()
    conn.close()
    return "User added!"

@app.route('/view')
def view_users():
    conn = sqlite3.connect('users.db')
    cursor = conn.execute('SELECT * FROM users')
    users = cursor.fetchall()
    conn.close()
    return render_template('view_users.html', users=users)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
